import './App.css';
import AppCar from './comps_hw/appCar';
import AppPixa from './comps_hw/appPixa';

function App() {
  return (
    <div className="App">
      <AppPixa />
      {/* <AppCar /> */}
    </div>
  );
}

export default App;
