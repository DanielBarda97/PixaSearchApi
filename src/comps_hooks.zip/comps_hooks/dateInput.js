import React from 'react';

function DateInput(props){
  return(
    <div>DateInput work</div> 
  )
}

export default DateInput