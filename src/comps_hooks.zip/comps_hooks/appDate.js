import React from 'react';
import DateInput from './dateInput';
import DateShow from './dateShow';

function AppDate(props){
  return(
    <div className="container">
      <DateShow />
      <DateInput />
    </div> 
  )
}

export default AppDate