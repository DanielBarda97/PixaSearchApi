import React from 'react';

function DateShow(props){
  return(
    <div>DateShow work</div> 
  )
}

export default DateShow